@echo off
:: =============================================================================
::  HamClock Advanced v3.1.0 — Windows Uninstaller
::  Removes the HamClock Advanced folder and desktop shortcut.
:: =============================================================================

echo.
echo  HamClock Advanced - Uninstaller
echo  This will remove HamClock Advanced from your computer.
echo.
set /p CONFIRM=Are you sure? (Y/N): 
if /i not "%CONFIRM%"=="Y" (
    echo Uninstall cancelled.
    pause
    exit /b 0
)

:: Remove Desktop shortcut
set "SHORTCUT=%USERPROFILE%\Desktop\HamClock Advanced.url"
if exist "%SHORTCUT%" (
    del /f "%SHORTCUT%"
    echo Removed desktop shortcut.
)

:: Remove Start Menu entry
set "STARTMENU=%APPDATA%\Microsoft\Windows\Start Menu\Programs\HamClock Advanced.url"
if exist "%STARTMENU%" (
    del /f "%STARTMENU%"
    echo Removed Start Menu entry.
)

echo.
echo  HamClock Advanced has been removed.
echo  You can delete this folder manually.
echo.
pause
