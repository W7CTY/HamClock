@echo off
:: =============================================================================
::  HamClock Advanced v3.1.0 — Windows Installer
::  Copies HamClockAdvanced.html to Program Files, creates desktop shortcut
::  and Start Menu entry, then launches the app.
::
::  W7CTY  w7cty@outlook.com
:: =============================================================================

setlocal EnableDelayedExpansion
echo.
echo  ============================================================
echo   HamClock Advanced v3.1.0 - Windows Installer
echo   Amateur Radio Operations Center by W7CTY
echo  ============================================================
echo.

:: Check for admin (needed for Program Files install)
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo  Requesting administrator privileges...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

set "SRC_DIR=%~dp0"
set "INSTALL_DIR=%ProgramFiles%\HamClock Advanced"
set "HTML_SRC=%SRC_DIR%HamClockAdvanced.html"
set "HTML_DEST=%INSTALL_DIR%\HamClockAdvanced.html"
set "BAT_DEST=%INSTALL_DIR%\Launch-HamClockAdvanced.bat"
set "UNINST_DEST=%INSTALL_DIR%\Uninstall.bat"
set "DESKTOP_SC=%PUBLIC%\Desktop\HamClock Advanced.url"
set "STARTMENU_DIR=%ProgramData%\Microsoft\Windows\Start Menu\Programs"
set "STARTMENU_SC=%STARTMENU_DIR%\HamClock Advanced.url"

:: Verify source files
if not exist "%HTML_SRC%" (
    echo  ERROR: HamClockAdvanced.html not found in this folder.
    echo  Make sure Install.bat and HamClockAdvanced.html are together.
    pause
    exit /b 1
)

:: Step 1: Create install directory
echo  [1/4] Creating install directory...
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
echo       %INSTALL_DIR%

:: Step 2: Copy files
echo  [2/4] Copying application files...
copy /y "%HTML_SRC%"              "%HTML_DEST%"  >nul
copy /y "%SRC_DIR%Launch-HamClockAdvanced.bat" "%BAT_DEST%"  >nul 2>nul || echo       (launcher copy skipped)
copy /y "%SRC_DIR%Uninstall.bat"  "%UNINST_DEST%" >nul 2>nul || echo       (uninstaller copy skipped)
echo       Done.

:: Step 3: Create desktop shortcut (.url file pointing to the HTML)
echo  [3/4] Creating desktop shortcut...
(
    echo [InternetShortcut]
    echo URL=file:///%INSTALL_DIR:\=/%/HamClockAdvanced.html
    echo IconIndex=0
) > "%DESKTOP_SC%"
echo       Desktop: %DESKTOP_SC%

:: Step 4: Create Start Menu shortcut
echo  [4/4] Creating Start Menu entry...
(
    echo [InternetShortcut]
    echo URL=file:///%INSTALL_DIR:\=/%/HamClockAdvanced.html
    echo IconIndex=0
) > "%STARTMENU_SC%"
echo       Start Menu: %STARTMENU_SC%

echo.
echo  ============================================================
echo   HamClock Advanced v3.1.0 installed successfully!
echo  ============================================================
echo.
echo   Launch from: Desktop shortcut  "HamClock Advanced"
echo           or:  Start Menu  ->  HamClock Advanced
echo           or:  %INSTALL_DIR%\HamClockAdvanced.html
echo.
echo   Uninstall:   Run %INSTALL_DIR%\Uninstall.bat
echo.
echo   Note: Requires an internet connection for map tiles
echo         and PSKReporter live DX paths.
echo.

:: Ask to launch now
set /p LAUNCH=Launch HamClock Advanced now? (Y/N): 
if /i "%LAUNCH%"=="Y" start "" "%HTML_DEST%"

echo.
echo  To UPDATE later: download the newest release from
echo    https://github.com/W7CTY/HamClock/releases/latest
echo    then run this Install.bat again.
echo  To UNINSTALL: run Uninstall.bat
echo.
pause
endlocal
