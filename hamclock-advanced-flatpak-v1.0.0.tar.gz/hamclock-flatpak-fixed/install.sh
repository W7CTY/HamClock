#!/usr/bin/env bash
# =============================================================================
#  HamClock Advanced — Quick Installer
#  Installs the pre-built .flatpak bundle if present, otherwise builds it.
#  Usage:  chmod +x install.sh && ./install.sh
# =============================================================================
set -euo pipefail

APP_ID="org.w7cty.HamClockAdvanced"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUNDLE="$SCRIPT_DIR/${APP_ID}.flatpak"

RED='\033[0;31m'; GRN='\033[0;32m'; YLW='\033[1;33m'
CYN='\033[0;36m'; BLD='\033[1m'; NC='\033[0m'
info(){ echo -e "${CYN}[INFO]${NC}  $*"; }
ok()  { echo -e "${GRN}[ OK ]${NC}  $*"; }
warn(){ echo -e "${YLW}[WARN]${NC}  $*"; }
die() { echo -e "${RED}[ERR ]${NC}  $*" >&2; exit 1; }

echo ""
echo -e "${YLW}${BLD}  HamClock Advanced — Installer${NC}"
echo -e "  Amateur Radio Operations Center by W7CTY"
echo ""

# ── Ensure flatpak is installed ───────────────────────────────────────────────
if ! command -v flatpak &>/dev/null; then
    info "Installing flatpak..."
    sudo dnf install -y flatpak || die "Could not install flatpak."
fi
ok "flatpak: $(flatpak --version)"

# ── Add Flathub remote ────────────────────────────────────────────────────────
flatpak remote-add --if-not-exists --user flathub \
    https://flathub.org/repo/flathub.flatpakrepo 2>/dev/null || true

# ── Install GNOME runtime (try 48 for Fedora 44, fall back to 46) ─────────────
RUNTIME_OK=false
for VER in 46 47 48; do
    if flatpak info --user org.gnome.Platform//${VER} &>/dev/null 2>&1 || \
       flatpak info        org.gnome.Platform//${VER} &>/dev/null 2>&1; then
        ok "GNOME Platform ${VER} already available."
        RUNTIME_OK=true; break
    fi
done

if ! $RUNTIME_OK; then
    info "Installing GNOME Platform 46 (supported runtime)..."
    flatpak install --user -y flathub \
        org.gnome.Platform//46 org.gnome.Sdk//46 2>/dev/null && \
        ok "GNOME Platform 46 installed." && RUNTIME_OK=true || true

    if ! $RUNTIME_OK; then
        info "Trying GNOME Platform 48..."
        flatpak install --user -y flathub \
            org.gnome.Platform//48 org.gnome.Sdk//48 2>/dev/null && \
            ok "GNOME Platform 48 installed." && RUNTIME_OK=true || true
    fi

    $RUNTIME_OK || die "Could not install GNOME runtime. Run manually:
  flatpak install --user flathub org.gnome.Platform//46 org.gnome.Sdk//46"
fi

# ── Install bundle or build from source ──────────────────────────────────────
if [[ -f "$BUNDLE" ]]; then
    info "Installing pre-built bundle: $(basename "$BUNDLE")"
    flatpak install --user -y "$BUNDLE"
else
    info "No pre-built bundle found — building from source..."
    # flatpak-builder is needed for building; install it now
    if ! command -v flatpak-builder &>/dev/null; then
        info "Installing flatpak-builder..."
        sudo dnf install -y flatpak-builder || \
            die "flatpak-builder not found and could not be installed.
Install manually:  sudo dnf install flatpak-builder"
    fi
    bash "$SCRIPT_DIR/build.sh" --install
    exit 0
fi

ok "HamClock Advanced installed!"
echo ""
echo -e "  ${CYN}Launch from terminal:${NC}  flatpak run ${APP_ID}"
echo -e "  ${CYN}Launch from desktop:${NC}   Activities → HamClock Advanced"
echo -e "  ${CYN}Uninstall:${NC}             flatpak uninstall --user ${APP_ID}"
echo ""
echo -e "  ${YLW}73 de W7CTY  ·  w7cty@outlook.com${NC}"
echo ""
