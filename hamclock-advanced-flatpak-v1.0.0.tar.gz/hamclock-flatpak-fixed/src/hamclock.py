#!/usr/bin/env python3
"""
HamClock Advanced — Amateur Radio Operations Center
GTK4 + WebKitGTK native application for Fedora Linux.
Fedora 44 / webkitgtk 2.52.x / WebKit 6.0 ready.
© 2026 W7CTY  w7cty@outlook.com
"""
import sys, os, signal

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")

# WebKit: try 6.0 (Fedora 38+) → 4.1 → 4.0
_WK_VER = None; _WK_PKG = None
for _mod, _ver, _pkg in [
    ("WebKit",  "6.0", "webkitgtk6.0"),
    ("WebKit2", "4.1", "webkit2gtk4.1"),
    ("WebKit2", "4.0", "webkit2gtk4.0"),
]:
    try:
        gi.require_version(_mod, _ver)
        from gi.repository import WebKit as _wk; _WK_VER=_ver; _WK_PKG=_pkg; WebKit=_wk; break
    except (ValueError, ImportError): pass

if _WK_VER is None:
    sys.exit("ERROR: WebKitGTK not found.\nInstall: sudo dnf install webkitgtk6.0")

from gi.repository import Gtk, Adw, GLib, Gio, Gdk

APP_ID  = "org.w7cty.HamClockAdvanced"
VERSION = "1.0.0"
DATA    = os.environ.get("HAMCLOCK_DATA", "/usr/share/hamclock-advanced")
HTML    = os.path.join(DATA, "hamclock.html")


def _make_webview():
    s = WebKit.Settings()
    s.set_enable_javascript(True)
    s.set_allow_file_access_from_file_urls(True)
    s.set_allow_universal_access_from_file_urls(True)
    for attr in ("set_javascript_can_access_clipboard",
                 "set_enable_developer_extras"):
        try: getattr(s, attr)(True)
        except AttributeError: pass
    if _WK_VER == "6.0":
        wv = WebKit.WebView(); wv.set_settings(s)
    else:
        for attr in ("set_enable_smooth_scrolling",):
            try: getattr(s, attr)(True)
            except AttributeError: pass
        try:
            s.set_hardware_acceleration_policy(WebKit.HardwareAccelerationPolicy.ALWAYS)
        except AttributeError: pass
        try:    wv = WebKit.WebView.new_with_settings(s)
        except AttributeError: wv = WebKit.WebView(); wv.set_settings(s)
    return wv


def _inject(wv, script):
    if _WK_VER == "6.0":
        wv.evaluate_javascript(script, -1, None, None, None, None, None)
    else:
        wv.run_javascript(script, None, None, None)


class HamClockWindow(Adw.ApplicationWindow):

    def __init__(self, app):
        super().__init__(application=app)
        self._fs = False
        self.set_title("HamClock Advanced")
        self.set_default_size(1440, 900)
        self._build(); self.connect("close-request", lambda *_: app.quit() or False)
        self.add_controller(self._keys())

    def _build(self):
        tv = Adw.ToolbarView(); self.set_content(tv)
        hb = Adw.HeaderBar()
        wt = Adw.WindowTitle()
        wt.set_title("HamClock Advanced")
        wt.set_subtitle("Amateur Radio Operations Center  ·  W7CTY")
        hb.set_title_widget(wt)

        def _btn(icon, tip, cb):
            b = Gtk.Button(icon_name=icon); b.set_tooltip_text(tip)
            b.connect("clicked", cb); return b

        hb.pack_start(_btn("view-refresh-symbolic",    "Reload  F5",        lambda _: self.wv.reload()))
        hb.pack_end(  _btn("help-about-symbolic",      "About",             lambda _: self._about()))
        hb.pack_end(  _btn("view-fullscreen-symbolic", "Fullscreen  F11",   lambda _: self._fullscreen()))
        hb.pack_end(  _btn("zoom-original-symbolic",   "Reset zoom  Ctrl+0",lambda _: self._zoom(1.0)))
        hb.pack_end(  _btn("zoom-out-symbolic",        "Zoom out  Ctrl−",   lambda _: self._adj(-0.1)))
        hb.pack_end(  _btn("zoom-in-symbolic",         "Zoom in  Ctrl+",    lambda _: self._adj(+0.1)))
        tv.add_top_bar(hb)

        self.wv = _make_webview()
        self.wv.set_vexpand(True); self.wv.set_hexpand(True)
        self.wv.connect("load-changed", self._loaded)
        tv.set_content(self.wv)
        self.wv.load_uri(f"file://{HTML}")

    def _loaded(self, wv, ev):
        if ev == WebKit.LoadEvent.FINISHED:
            _inject(wv,
                "window.__hamclockNative=true;"
                f"window.__hamclockVersion='{VERSION}';"
                f"window.__webkitVersion='{_WK_VER}';"
                "document.dispatchEvent(new CustomEvent('nativeReady'));")

    def _keys(self):
        kc = Gtk.EventControllerKey()
        kc.connect("key-pressed", self._key); return kc

    def _key(self, _c, kv, _kc, mod):
        C = bool(mod & Gdk.ModifierType.CONTROL_MASK)
        if kv == Gdk.KEY_F5:              self.wv.reload();      return True
        if kv == Gdk.KEY_F11:             self._fullscreen();    return True
        if kv == Gdk.KEY_Escape and self._fs: self._fullscreen();return True
        if C:
            if kv in (Gdk.KEY_equal, Gdk.KEY_plus, Gdk.KEY_KP_Add):    self._adj(+0.1); return True
            if kv in (Gdk.KEY_minus, Gdk.KEY_KP_Subtract):              self._adj(-0.1); return True
            if kv in (Gdk.KEY_0, Gdk.KEY_KP_0):                        self._zoom(1.0); return True
            if kv in (Gdk.KEY_r, Gdk.KEY_R):                            self.wv.reload();return True
            if kv in (Gdk.KEY_q, Gdk.KEY_Q): self.get_application().quit(); return True
        return False

    def _fullscreen(self):
        if self._fs: self.unfullscreen()
        else:        self.fullscreen()
        self._fs = not self._fs

    def _adj(self, d):
        z = round(self.wv.get_zoom_level()+d, 1)
        self.wv.set_zoom_level(max(0.25, min(4.0, z)))

    def _zoom(self, v): self.wv.set_zoom_level(v)

    def _about(self):
        a = Adw.AboutWindow(transient_for=self)
        a.set_application_name("HamClock Advanced")
        a.set_version(VERSION); a.set_developer_name("W7CTY")
        a.set_application_icon(APP_ID)
        a.set_comments(
            "Amateur Radio Operations Center\n\n"
            "HF Conditions · DX Spots · NatGeo Map\n"
            "World Clocks · QSO Logger · Gray Line\n\n"
            f"WebKit {_WK_VER} ({_WK_PKG})")
        a.set_license_type(Gtk.License.GPL_3_0)
        a.set_copyright("© 2026 W7CTY")
        a.set_developers(["W7CTY <w7cty@outlook.com>"])
        a.set_website("https://github.com/w7cty/hamclock-advanced")
        a.present()


class HamClockApp(Adw.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID,
                         flags=Gio.ApplicationFlags.DEFAULT_FLAGS)
        self._win = None; self.connect("activate", self._act)

    def _act(self, _):
        if not self._win: self._win = HamClockWindow(self)
        self._win.present()


def main():
    signal.signal(signal.SIGINT, signal.SIG_DFL)
    if not os.path.isfile(HTML):
        sys.exit(f"ERROR: Cannot find hamclock.html\n  Expected: {HTML}\n"
                 f"  Override: HAMCLOCK_DATA=/path/to/dir hamclock-advanced")
    print(f"HamClock Advanced {VERSION} — WebKit {_WK_VER} ({_WK_PKG})")
    HamClockApp().run(sys.argv)


if __name__ == "__main__":
    main()
