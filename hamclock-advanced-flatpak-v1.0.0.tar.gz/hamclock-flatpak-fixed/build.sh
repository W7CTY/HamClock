#!/usr/bin/env bash
# =============================================================================
#  HamClock Advanced — Flatpak Build Script
#  Usage:  chmod +x build.sh && ./build.sh
#          ./build.sh --install      # build + install immediately
# =============================================================================
set -euo pipefail

APP_ID="org.w7cty.HamClockAdvanced"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_DIR="$SCRIPT_DIR/src"
MANIFEST="$SCRIPT_DIR/flatpak/${APP_ID}.yaml"
REPO_DIR="$SCRIPT_DIR/build/repo"
BUILD_DIR="$SCRIPT_DIR/build/build-dir"
BUNDLE="$SCRIPT_DIR/${APP_ID}.flatpak"

RED='\033[0;31m'; GRN='\033[0;32m'; YLW='\033[1;33m'
CYN='\033[0;36m'; BLD='\033[1m'; NC='\033[0m'
info(){ echo -e "${CYN}[INFO]${NC}  $*"; }
ok()  { echo -e "${GRN}[ OK ]${NC}  $*"; }
warn(){ echo -e "${YLW}[WARN]${NC}  $*"; }
die() { echo -e "${RED}[ERR ]${NC}  $*" >&2; exit 1; }

echo -e "${YLW}${BLD}  HamClock Advanced — Flatpak Build — by W7CTY${NC}"
echo ""

# ── Fedora version ────────────────────────────────────────────────────────────
FEDORA_VER="?"
[[ -f /etc/fedora-release ]] && \
    FEDORA_VER=$(rpm -q --queryformat '%{VERSION}' fedora-release 2>/dev/null || echo "?")
info "Fedora $FEDORA_VER"

# ── Step 1: Install flatpak + flatpak-builder ─────────────────────────────────
# NOTE: flatpak-builder is a SEPARATE package — dnf install flatpak alone
#       does NOT install it. We install both and locate the binary explicitly.
info "Step 1/5 — Installing flatpak and flatpak-builder..."

sudo dnf install -y flatpak flatpak-builder 2>/dev/null \
    || die "dnf install failed. Check your internet connection."

# Locate flatpak-builder with absolute path — avoids PATH/hash cache issues
FPB=""
for loc in /usr/bin/flatpak-builder /usr/local/bin/flatpak-builder \
           /bin/flatpak-builder "$(command -v flatpak-builder 2>/dev/null)"; do
    [[ -x "$loc" ]] && FPB="$loc" && break
done
[[ -n "$FPB" ]] || die "flatpak-builder not found after install.
Try:  sudo dnf install -y flatpak-builder
Then re-run this script."
ok "flatpak-builder: $FPB"

# ── Step 2: Flathub + GNOME runtime ──────────────────────────────────────────
info "Step 2/5 — Setting up Flathub and GNOME runtime..."

flatpak remote-add --if-not-exists --user flathub \
    https://flathub.org/repo/flathub.flatpakrepo 2>/dev/null || true

# Detect or install runtime — prefer 46 (supported LTS), avoid 48 (EOL Mar 2026)
RUNTIME_VER=""
for VER in 46 47 48; do
    if flatpak info --user org.gnome.Platform//${VER} &>/dev/null 2>&1 || \
       flatpak info        org.gnome.Platform//${VER} &>/dev/null 2>&1; then
        RUNTIME_VER="$VER"; ok "GNOME Platform ${VER} already installed."; break
    fi
done

if [[ -z "$RUNTIME_VER" ]]; then
    info "Installing GNOME Platform 46..."
    if flatpak install --user -y flathub \
           org.gnome.Platform//46 org.gnome.Sdk//46 2>/dev/null; then
        RUNTIME_VER="46"; ok "GNOME Platform 46 installed."
    else
        warn "Platform 46 unavailable — trying 48..."
        flatpak install --user -y flathub \
            org.gnome.Platform//48 org.gnome.Sdk//48 2>/dev/null \
            && RUNTIME_VER="48" && ok "GNOME Platform 48 installed." \
            || die "Could not install GNOME runtime.
Run manually:  flatpak install --user flathub org.gnome.Platform//46 org.gnome.Sdk//46"
    fi
fi

# Patch manifest to match installed runtime version
sed -i "s/^runtime-version: .*/runtime-version: '${RUNTIME_VER}'/" "$MANIFEST"
info "Manifest: GNOME Platform ${RUNTIME_VER}"

# ── Step 3: Stage sources ─────────────────────────────────────────────────────
info "Step 3/5 — Staging sources..."
FLATPAK_DIR="$(dirname "$MANIFEST")"
cp "$SRC_DIR"/*.py "$SRC_DIR"/*.html "$SRC_DIR"/*.desktop \
   "$SRC_DIR"/*.xml "$SRC_DIR"/*.svg \
   "$SRC_DIR"/hamclock-wrapper \
   "$FLATPAK_DIR/"
ok "Sources staged."

# ── Step 4: Build with flatpak-builder (absolute path) ───────────────────────
info "Step 4/5 — Running flatpak-builder..."
mkdir -p "$REPO_DIR"
"$FPB" \
    --repo="$REPO_DIR" \
    --force-clean \
    --user \
    "$BUILD_DIR" \
    "$MANIFEST"
ok "Build complete."

# ── Step 5: Create bundle ─────────────────────────────────────────────────────
info "Step 5/5 — Creating .flatpak bundle..."
flatpak build-bundle "$REPO_DIR" "$BUNDLE" "$APP_ID"
ok "Bundle: $BUNDLE"

# ── Optional install ──────────────────────────────────────────────────────────
if [[ "${1:-}" == "--install" ]]; then
    info "Installing..."
    flatpak install --user -y "$BUNDLE"
    ok "Installed. Run:  flatpak run $APP_ID"
fi

echo ""
echo -e "${GRN}${BLD}  HamClock Advanced bundle ready: $(basename "$BUNDLE")${NC}"
echo -e "  Install:   flatpak install --user $(basename "$BUNDLE")"
echo -e "  Run:       flatpak run $APP_ID"
echo -e "  Remove:    flatpak uninstall --user $APP_ID"
echo -e "  ${YLW}73 de W7CTY${NC}"
echo ""
