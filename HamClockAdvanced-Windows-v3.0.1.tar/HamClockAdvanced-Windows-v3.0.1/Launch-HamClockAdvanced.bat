@echo off
:: =============================================================================
::  HamClock Advanced v3.0.1 — Windows Launcher
::  Opens HamClockAdvanced.html in your default browser.
::  Double-click this file to launch HamClock Advanced.
::  W7CTY  w7cty@outlook.com
:: =============================================================================

setlocal
set "APP_DIR=%~dp0"
set "APP_FILE=%APP_DIR%HamClockAdvanced.html"

if not exist "%APP_FILE%" (
    echo ERROR: HamClockAdvanced.html not found.
    echo Make sure Launch-HamClockAdvanced.bat and HamClockAdvanced.html
    echo are in the same folder.
    pause
    exit /b 1
)

start "" "%APP_FILE%"
endlocal
