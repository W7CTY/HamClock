# HamClock Advanced — v3.0.1

**Full-featured Amateur Radio Operations Center**
Developed by **W7CTY** · w7cty@outlook.com

---

## What's New in v3.0.1

| Change | Details |
|---|---|
| **Live PSKReporter DX paths** | Real-time great-circle paths from stations that heard your signal |
| **No activity = no paths** | Map is completely clean when no reports exist for your callsign |
| **Radio antenna icon** | Yagi antenna SVG replaces the circular icon in the banner |
| **MENU button** | Red-border gold-font MENU button replaces the gear icon |
| **Ticker +75%** | Taller, larger font, centered, always gold/black/red-border |
| **Version in footer** | v3.0.1 shown in footer bar |

---

## Packages

| File | Platform | Method |
|---|---|---|
| `hamclock-public.html` | Any browser | Open directly |
| `hamclock-advanced-3.0.1-1.x86_64.rpm` | Fedora Linux | `sudo dnf install` |
| `hamclock-advanced-fedora-update-v3.0.1.tar.gz` | Fedora (existing install) | `./update.sh` |
| `hamclock-advanced-flatpak-v3.0.1.tar.gz` | Fedora/Linux Flatpak | `./install.sh` |
| `hamclock-advanced-linux-v3.0.1.tar.gz` | Any Linux distro | `./install.sh` |

---

## Browser Version

```bash
xdg-open hamclock-public.html   # Linux
open hamclock-public.html       # macOS
start hamclock-public.html      # Windows
```

---

## Fedora RPM — Fresh Install

```bash
sudo dnf install hamclock-advanced-3.0.1-1.x86_64.rpm
hamclock-advanced
```

**Uninstall:**
```bash
sudo dnf remove hamclock-advanced
# or to remove all versions including old hamclock-improved:
sudo bash /usr/share/hamclock-advanced/uninstall-hamclock.sh
```

---

## Fedora — Update from Previous Version

```bash
tar -xzf hamclock-advanced-fedora-update-v3.0.1.tar.gz
cd hamclock-fedora-update
chmod +x update.sh && ./update.sh
```

Automatically detects and removes `hamclock-improved` or any older `hamclock-advanced`, then installs v3.0.1.

---

## Fedora Flatpak

```bash
tar -xzf hamclock-advanced-flatpak-v3.0.1.tar.gz -C ~/Downloads
cd ~/Downloads/hamclock-flatpak-fixed
chmod +x install.sh && ./install.sh
flatpak run org.w7cty.HamClockAdvanced
```

**Uninstall:** `flatpak uninstall --user org.w7cty.HamClockAdvanced`

**Troubleshooting:**

| Error | Fix |
|---|---|
| `flatpak-builder: command not found` | `sudo dnf install -y flatpak-builder` |
| `Cannot mkdir: Permission denied` | Run `cd ~/Downloads` before `tar` |
| `This version is already installed` | Uninstall first, then re-run install.sh |
| GNOME Platform 48 EOL warning | This package uses Platform 46 — reinstall with this package |

---

## Universal Linux Installer (Any Distro)

```bash
tar -xzf hamclock-advanced-linux-v3.0.1.tar.gz
cd hamclock-advanced-linux
chmod +x install.sh && ./install.sh
hamclock-advanced
```

Supports: **Fedora** (dnf) · **Ubuntu/Debian** (apt) · **Arch** (pacman) · **openSUSE** (zypper) · **Alpine** (apk) · **Void** (xbps) · **Gentoo** (emerge)

**Uninstall:** `sudo bash /opt/hamclock-advanced/uninstall.sh`

---

## Features

### Live DX Paths — PSKReporter
- Queries `retrieve.pskreporter.info` for stations that heard **your callsign** in the last 15 minutes
- Draws red great-circle paths — **no paths when no activity**
- Refreshes every 5 minutes; re-queries when callsign changes
- Receiver dots are clickable: callsign, frequency, mode, SNR, grid
- Status bar: 🟢 live · 🟡 loading · ⚫ no activity

### HF Band Conditions
- 160m–6m with day AND night quality always visible; active period highlighted

### Interactive Map
- Esri National Geographic tiles · Gray-line terminator · Grid square overlay
- Expandable to 620px · Floating toolbar

### DX Cluster Spots
- Up to 25 spots · Band and mode filtering · DXCC count

### World Clocks
- UTC + local (auto from grid) locked · Slots 3–8 user-selectable

### QSO Logger
- FT8/FT4, SSB, CW, DMR, D-STAR, C4FM, FM, RTTY, PSK31
- POTA, SOTA, Field Day, Other operation types
- Local log + QRZ Logbook API upload

### Settings (MENU button)
- Dark Mode · Font Size 100–200% · Expand Map · QRZ API Key · Share App

---

## Keyboard Shortcuts (Native App)

| Key | Action |
|---|---|
| F5 | Reload |
| F11 | Fullscreen |
| Esc | Exit fullscreen |
| Ctrl +/−/0 | Zoom in/out/reset |
| Ctrl Q | Quit |

---

## License
© 2026 W7CTY · All Rights Reserved · Personal/non-commercial use permitted

**W7CTY** · w7cty@outlook.com · *73 de W7CTY — Good DX!*
