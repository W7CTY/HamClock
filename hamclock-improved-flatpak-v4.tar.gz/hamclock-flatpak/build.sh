#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════════════
#  HamClock Improved — Flatpak Build Script
#  Builds a .flatpak bundle from source.
#  Usage:  ./build.sh
#          ./build.sh --install      (build + install for current user)
# ══════════════════════════════════════════════════════════════════════════════

set -euo pipefail

APP_ID="org.w7cty.HamClockImproved"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_DIR="$SCRIPT_DIR/src"
MANIFEST="$SCRIPT_DIR/flatpak/${APP_ID}.yaml"
BUILD_DIR="$SCRIPT_DIR/build/repo"
BUNDLE="$SCRIPT_DIR/${APP_ID}.flatpak"

# ── Colours ───────────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'
info()    { echo -e "${CYAN}[INFO]${NC}  $*"; }
success() { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC}  $*"; }
die()     { echo -e "${RED}[ERROR]${NC} $*" >&2; exit 1; }

# ── Banner ────────────────────────────────────────────────────────────────────
echo -e "${YELLOW}${BOLD}"
cat << 'EOF'
  ██╗  ██╗ █████╗ ███╗   ███╗ ██████╗██╗      ██████╗  ██████╗██╗  ██╗
  ██║  ██║██╔══██╗████╗ ████║██╔════╝██║     ██╔═══██╗██╔════╝██║ ██╔╝
  ███████║███████║██╔████╔██║██║     ██║     ██║   ██║██║     █████╔╝
  ██╔══██║██╔══██║██║╚██╔╝██║██║     ██║     ██║   ██║██║     ██╔═██╗
  ██║  ██║██║  ██║██║ ╚═╝ ██║╚██████╗███████╗╚██████╔╝╚██████╗██║  ██╗
  ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝ ╚═════╝╚══════╝ ╚═════╝  ╚═════╝╚═╝  ╚═╝
EOF
echo -e "${NC}  IMPROVED · Flatpak Build  ·  by W7CTY${NC}"
echo ""

# ── Fedora check ──────────────────────────────────────────────────────────────
if [[ -f /etc/fedora-release ]]; then
    FEDORA_VER=$(rpm -q --queryformat '%{VERSION}' fedora-release 2>/dev/null || echo "?")
    success "Fedora $FEDORA_VER detected"
fi

# ── Check dependencies ────────────────────────────────────────────────────────
info "Checking build dependencies..."
MISSING=()
for pkg in flatpak flatpak-builder; do
    if ! command -v "${pkg%%-*}" &>/dev/null && ! rpm -q "$pkg" &>/dev/null 2>&1; then
        MISSING+=("$pkg")
    fi
done

if [[ ${#MISSING[@]} -gt 0 ]]; then
    warn "Missing packages: ${MISSING[*]}"
    read -rp "Install them now? [Y/n] " ans; ans="${ans:-y}"
    [[ "${ans,,}" == "y" ]] && sudo dnf install -y "${MISSING[@]}" || die "Cannot proceed without $*"
fi
success "Build dependencies present."

# ── Add GNOME runtime (required by manifest) ──────────────────────────────────
info "Checking Flatpak GNOME runtime..."
if ! flatpak info org.gnome.Platform//46 &>/dev/null; then
    info "Adding Flathub remote and installing GNOME Platform 46..."
    flatpak remote-add --if-not-exists --user flathub https://flathub.org/repo/flathub.flatpakrepo
    flatpak install --user -y flathub org.gnome.Platform//46 org.gnome.Sdk//46 || \
        warn "Could not auto-install GNOME runtime. Run manually if build fails."
fi

# ── Copy sources into flatpak manifest dir ────────────────────────────────────
info "Staging source files..."
cp "$SRC_DIR/"*.py "$SRC_DIR/"*.html "$SRC_DIR/"*.desktop \
   "$SRC_DIR/"*.xml "$SRC_DIR/"*.svg \
   "$(dirname "$MANIFEST")/"
success "Sources staged."

# ── Build ─────────────────────────────────────────────────────────────────────
info "Running flatpak-builder..."
mkdir -p "$BUILD_DIR"
flatpak-builder \
    --repo="$BUILD_DIR" \
    --force-clean \
    --user \
    "$SCRIPT_DIR/build/build-dir" \
    "$MANIFEST"

success "Build complete."

# ── Create .flatpak bundle ────────────────────────────────────────────────────
info "Creating .flatpak bundle..."
flatpak build-bundle \
    "$BUILD_DIR" \
    "$BUNDLE" \
    "$APP_ID"

success "Bundle created: $BUNDLE"

# ── Optionally install ────────────────────────────────────────────────────────
if [[ "${1:-}" == "--install" ]]; then
    info "Installing..."
    flatpak install --user -y "$BUNDLE"
    success "Installed. Launch with:  flatpak run $APP_ID"
fi

echo ""
echo -e "${GREEN}${BOLD}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}${BOLD}║        HamClock Improved .flatpak bundle ready!       ║${NC}"
echo -e "${GREEN}${BOLD}╚═══════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  ${CYAN}Bundle:${NC}   $BUNDLE"
echo -e "  ${CYAN}Install:${NC}  flatpak install --user ${APP_ID}.flatpak"
echo -e "  ${CYAN}Run:${NC}      flatpak run ${APP_ID}"
echo -e "  ${CYAN}Remove:${NC}   flatpak uninstall --user ${APP_ID}"
echo ""
echo -e "  ${YELLOW}73 de W7CTY${NC}"
echo ""
