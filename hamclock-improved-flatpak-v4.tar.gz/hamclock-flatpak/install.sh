#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════════════
#  HamClock Improved — Quick Installer
#  Installs the pre-built .flatpak bundle (if present) OR builds from source.
#  Usage:  ./install.sh
# ══════════════════════════════════════════════════════════════════════════════

set -euo pipefail

APP_ID="org.w7cty.HamClockImproved"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUNDLE="$SCRIPT_DIR/${APP_ID}.flatpak"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'
info()    { echo -e "${CYAN}[INFO]${NC}  $*"; }
success() { echo -e "${GREEN}[OK]${NC}    $*"; }
die()     { echo -e "${RED}[ERROR]${NC} $*" >&2; exit 1; }

echo ""
echo -e "${YELLOW}${BOLD}  HamClock Improved — Installer${NC}"
echo -e "  Amateur Radio Operations Center by W7CTY"
echo ""

# ── Ensure Flatpak is available ───────────────────────────────────────────────
if ! command -v flatpak &>/dev/null; then
    info "Installing flatpak via dnf..."
    sudo dnf install -y flatpak || die "Could not install flatpak"
fi
success "Flatpak available."

# ── Add Flathub remote ────────────────────────────────────────────────────────
flatpak remote-add --if-not-exists --user flathub \
    https://flathub.org/repo/flathub.flatpakrepo 2>/dev/null || true

# ── Install GNOME runtime if missing ─────────────────────────────────────────
if ! flatpak info org.gnome.Platform//46 &>/dev/null; then
    info "Installing GNOME Platform 46 runtime (required)..."
    flatpak install --user -y flathub \
        org.gnome.Platform//46 \
        org.gnome.Sdk//46 2>/dev/null || \
        warn "Could not install GNOME runtime — build step may handle this."
fi

# ── Install bundle or build ───────────────────────────────────────────────────
if [[ -f "$BUNDLE" ]]; then
    info "Installing pre-built bundle: $BUNDLE"
    flatpak install --user -y "$BUNDLE"
else
    info "No pre-built bundle found. Building from source..."
    bash "$SCRIPT_DIR/build.sh" --install
fi

success "HamClock Improved installed!"
echo ""
echo -e "  ${CYAN}Launch from terminal:${NC}  flatpak run ${APP_ID}"
echo -e "  ${CYAN}Launch from desktop:${NC}   Activities → HamClock Improved"
echo -e "  ${CYAN}Uninstall:${NC}             flatpak uninstall --user ${APP_ID}"
echo ""
