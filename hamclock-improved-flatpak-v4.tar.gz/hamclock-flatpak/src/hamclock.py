#!/usr/bin/env python3
"""
HamClock Improved — Amateur Radio Operations Center
Flatpak GTK4 + WebKitGTK application.
App ID: org.w7cty.HamClockImproved
"""

import sys
import os
import signal
import gi

# Require GTK4 + WebKit (6.0 for GTK4 / 4.1 for GTK3 fallback)
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")

try:
    gi.require_version("WebKit", "6.0")
    from gi.repository import WebKit as WK
    WEBKIT_VERSION = "6.0"
except ValueError:
    try:
        gi.require_version("WebKit2", "4.1")
        from gi.repository import WebKit2 as WK
        WEBKIT_VERSION = "4.1"
    except ValueError:
        gi.require_version("WebKit2", "4.0")
        from gi.repository import WebKit2 as WK
        WEBKIT_VERSION = "4.0"

from gi.repository import Gtk, Adw, GLib, Gio, Gdk

APP_ID   = "org.w7cty.HamClockImproved"
VERSION  = "1.0.0"

# HTML is shipped alongside this script inside the Flatpak
SCRIPT_DIR = os.path.dirname(os.path.realpath(__file__))
HTML_FILE  = os.path.join(SCRIPT_DIR, "hamclock.html")


# ──────────────────────────────────────────────────────────────────────────────
class HamClockWindow(Adw.ApplicationWindow):

    def __init__(self, app):
        super().__init__(application=app)
        self.app = app
        self._fullscreen = False
        self._setup_window()
        self._build_ui()
        self.present()

    # ── Window setup ─────────────────────────────────────────────────────────
    def _setup_window(self):
        self.set_title("HamClock Improved")
        self.set_default_size(1400, 900)

        # Dark title-bar
        sm = Gtk.Settings.get_default()
        sm.set_property("gtk-application-prefer-dark-theme", True)

        # Keyboard shortcuts
        self.add_controller(self._make_key_controller())

        self.connect("close-request", lambda *_: self.app.quit() or False)

    # ── Build UI ─────────────────────────────────────────────────────────────
    def _build_ui(self):
        # Root: ToolbarView (Adwaita pattern)
        toolbar_view = Adw.ToolbarView()
        self.set_content(toolbar_view)

        # ── Header bar ───────────────────────────────────────────────────────
        hb = Adw.HeaderBar()
        hb.set_show_title(True)

        # Title widget
        title = Adw.WindowTitle()
        title.set_title("HamClock Improved")
        title.set_subtitle("Amateur Radio Operations Center")
        hb.set_title_widget(title)

        # Left: reload
        btn_reload = Gtk.Button(icon_name="view-refresh-symbolic")
        btn_reload.set_tooltip_text("Reload (F5)")
        btn_reload.connect("clicked", lambda _: self.webview.reload())
        hb.pack_start(btn_reload)

        # Right: zoom controls + fullscreen
        zoom_out = Gtk.Button(icon_name="zoom-out-symbolic")
        zoom_out.set_tooltip_text("Zoom out  Ctrl−")
        zoom_out.connect("clicked", lambda _: self._zoom(-0.1))

        zoom_in = Gtk.Button(icon_name="zoom-in-symbolic")
        zoom_in.set_tooltip_text("Zoom in  Ctrl+")
        zoom_in.connect("clicked", lambda _: self._zoom(+0.1))

        zoom_reset = Gtk.Button(icon_name="zoom-original-symbolic")
        zoom_reset.set_tooltip_text("Reset zoom  Ctrl+0")
        zoom_reset.connect("clicked", lambda _: self._zoom_reset())

        btn_fs = Gtk.Button(icon_name="view-fullscreen-symbolic")
        btn_fs.set_tooltip_text("Fullscreen  F11")
        btn_fs.connect("clicked", lambda _: self._toggle_fullscreen())

        btn_about = Gtk.Button(icon_name="help-about-symbolic")
        btn_about.set_tooltip_text("About HamClock Improved")
        btn_about.connect("clicked", lambda _: self._show_about())

        for w in (zoom_out, zoom_in, zoom_reset, btn_fs, btn_about):
            hb.pack_end(w)

        toolbar_view.add_top_bar(hb)

        # ── WebView ──────────────────────────────────────────────────────────
        self.webview = self._make_webview()
        toolbar_view.set_content(self.webview)

        # Load the app
        self.webview.load_uri(f"file://{HTML_FILE}")

    # ── WebView factory ───────────────────────────────────────────────────────
    def _make_webview(self):
        if WEBKIT_VERSION == "6.0":
            settings = WK.Settings()
            settings.set_enable_javascript(True)
            settings.set_enable_developer_extras(True)
            settings.set_javascript_can_access_clipboard(True)
            settings.set_allow_file_access_from_file_urls(True)
            settings.set_allow_universal_access_from_file_urls(True)
            wv = WK.WebView()
            wv.set_settings(settings)
        else:
            # WebKit2
            settings = WK.Settings()
            settings.set_enable_javascript(True)
            settings.set_enable_developer_extras(True)
            settings.set_javascript_can_access_clipboard(True)
            settings.set_allow_file_access_from_file_urls(True)
            settings.set_allow_universal_access_from_file_urls(True)
            settings.set_enable_smooth_scrolling(True)
            settings.set_hardware_acceleration_policy(
                WK.HardwareAccelerationPolicy.ALWAYS
            )
            wv = WK.WebView.new_with_settings(settings)

        wv.set_vexpand(True)
        wv.set_hexpand(True)
        wv.connect("load-changed", self._on_load_changed)
        return wv

    # ── Key bindings ──────────────────────────────────────────────────────────
    def _make_key_controller(self):
        kc = Gtk.EventControllerKey()
        kc.connect("key-pressed", self._on_key_pressed)
        return kc

    def _on_key_pressed(self, _ctrl, keyval, _keycode, state):
        ctrl = bool(state & Gdk.ModifierType.CONTROL_MASK)
        K    = Gdk.KEY_

        if keyval == Gdk.KEY_F11:                   self._toggle_fullscreen(); return True
        if keyval == Gdk.KEY_F5:                    self.webview.reload();     return True
        if keyval == Gdk.KEY_Escape and self._fullscreen:
            self._toggle_fullscreen(); return True
        if ctrl and keyval in (Gdk.KEY_equal, Gdk.KEY_plus, Gdk.KEY_KP_Add):
            self._zoom(+0.1); return True
        if ctrl and keyval in (Gdk.KEY_minus, Gdk.KEY_KP_Subtract):
            self._zoom(-0.1); return True
        if ctrl and keyval in (Gdk.KEY_0, Gdk.KEY_KP_0):
            self._zoom_reset(); return True
        if ctrl and keyval in (Gdk.KEY_q, Gdk.KEY_Q):
            self.app.quit(); return True
        return False

    # ── Helpers ───────────────────────────────────────────────────────────────
    def _toggle_fullscreen(self):
        if self._fullscreen:
            self.unfullscreen()
        else:
            self.fullscreen()
        self._fullscreen = not self._fullscreen

    def _zoom(self, delta):
        z = round(self.webview.get_zoom_level() + delta, 1)
        self.webview.set_zoom_level(max(0.3, min(3.0, z)))

    def _zoom_reset(self):
        self.webview.set_zoom_level(1.0)

    def _on_load_changed(self, _wv, event):
        # Inject JS to let the page know it's running inside the native app
        if WEBKIT_VERSION == "6.0":
            finished = WK.LoadEvent.FINISHED
        else:
            finished = WK.LoadEvent.FINISHED
        if event == finished:
            self.webview.evaluate_javascript(
                "window.__hamclockNative=true; "
                "document.dispatchEvent(new CustomEvent('nativeReady'));",
                -1, None, None, None, None, None
            ) if WEBKIT_VERSION == "6.0" else \
            self.webview.run_javascript(
                "window.__hamclockNative=true; "
                "document.dispatchEvent(new CustomEvent('nativeReady'));",
                None, None, None
            )

    def _show_about(self):
        about = Adw.AboutWindow(transient_for=self)
        about.set_application_name("HamClock Improved")
        about.set_version(VERSION)
        about.set_developer_name("W7CTY")
        about.set_application_icon(APP_ID)
        about.set_website("mailto:w7cty@outlook.com")
        about.set_issue_url("mailto:w7cty@outlook.com")
        about.set_comments(
            "Amateur Radio Operations Center\n\n"
            "HF Conditions · DX Spots · NatGeo Propagation Map\n"
            "World Clocks · QSO Logger · Gray Line"
        )
        about.set_license_type(Gtk.License.GPL_3_0)
        about.set_copyright("© 2026 W7CTY")
        about.set_developers(["W7CTY <w7cty@outlook.com>"])
        about.present()


# ──────────────────────────────────────────────────────────────────────────────
class HamClockApp(Adw.Application):

    def __init__(self):
        super().__init__(
            application_id=APP_ID,
            flags=Gio.ApplicationFlags.DEFAULT_FLAGS,
        )
        self.window = None
        self.connect("activate", self._on_activate)

    def _on_activate(self, _app):
        if not self.window:
            self.window = HamClockWindow(self)
        else:
            self.window.present()

    def do_startup(self):
        Adw.Application.do_startup(self)

    def do_shutdown(self):
        Adw.Application.do_shutdown(self)


# ──────────────────────────────────────────────────────────────────────────────
def main():
    signal.signal(signal.SIGINT, signal.SIG_DFL)
    if not os.path.isfile(HTML_FILE):
        sys.exit(f"ERROR: Cannot find hamclock.html at:\n  {HTML_FILE}")
    app = HamClockApp()
    sys.exit(app.run(sys.argv))


if __name__ == "__main__":
    main()
