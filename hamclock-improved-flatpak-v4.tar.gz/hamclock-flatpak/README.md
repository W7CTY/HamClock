# HamClock Improved — Flatpak for Fedora Linux

**App ID:** `org.w7cty.HamClockImproved`  
**Developer:** W7CTY · w7cty@outlook.com  
**Runtime:** GNOME Platform 46 (GTK4 + Adwaita + WebKitGTK)

---

## Quick Install

```bash
chmod +x install.sh
./install.sh
```

That's it. The script handles everything: installs Flatpak, adds Flathub,
installs the GNOME runtime, and installs HamClock Improved.

---

## Launch

```bash
# Terminal
flatpak run org.w7cty.HamClockImproved

# Or: Activities (Super key) → search "HamClock"
```

---

## Building from Source

If you want to build the `.flatpak` bundle yourself:

### Prerequisites

```bash
sudo dnf install flatpak flatpak-builder
flatpak remote-add --if-not-exists --user flathub \
    https://flathub.org/repo/flathub.flatpakrepo
flatpak install --user flathub org.gnome.Platform//46 org.gnome.Sdk//46
```

### Build

```bash
chmod +x build.sh
./build.sh                 # builds org.w7cty.HamClockImproved.flatpak
./build.sh --install       # builds and installs in one step
```

The `.flatpak` bundle file can be distributed and installed on any Fedora
(or other Linux) system that has Flatpak installed.

---

## Keyboard Shortcuts

| Key | Action |
|---|---|
| `F5` | Reload |
| `F11` | Toggle fullscreen |
| `Esc` | Exit fullscreen |
| `Ctrl` `+` | Zoom in |
| `Ctrl` `-` | Zoom out |
| `Ctrl` `0` | Reset zoom |
| `Ctrl` `Q` | Quit |

---

## File Layout

```
hamclock-flatpak/
├── src/
│   ├── hamclock.py                        ← GTK4/Adwaita application
│   ├── hamclock.html                      ← Full HamClock Improved UI
│   ├── org.w7cty.HamClockImproved.svg     ← App icon
│   ├── org.w7cty.HamClockImproved.desktop ← Launcher entry
│   └── org.w7cty.HamClockImproved.metainfo.xml ← AppStream metadata
├── flatpak/
│   └── org.w7cty.HamClockImproved.yaml   ← Flatpak manifest
├── build.sh                               ← Build script
├── install.sh                             ← One-step installer
└── README.md                              ← This file
```

After building:
```
org.w7cty.HamClockImproved.flatpak        ← Distributable bundle
```

---

## Uninstall

```bash
flatpak uninstall --user org.w7cty.HamClockImproved
```

---

## Requirements

| Component | Version |
|---|---|
| Fedora | 38 or later (any version with Flatpak) |
| Flatpak | 1.12+ |
| GNOME Platform | 46 (auto-installed from Flathub) |
| Internet | For map tiles and Google Fonts |

The GNOME Platform runtime includes WebKitGTK, GTK4, and libadwaita —
no extra packages needed.

---

## Technical Notes

- The app uses **GTK4 + libadwaita** for the native window chrome,
  keyboard shortcuts, zoom controls, and about dialog.
- The HamClock Improved HTML dashboard is loaded via **WebKitGTK** inside
  the native window — giving it full JavaScript, CSS, and Leaflet map support.
- The Flatpak sandbox grants network access (for map tiles and DX cluster),
  GPU/DRI access (for hardware-accelerated map rendering), and home directory
  access (for localStorage-based preferences).
- Preferences (callsign, grid, theme) are stored in WebKit's localStorage
  and persisted in the Flatpak sandbox's home directory access.

---

73 de W7CTY
