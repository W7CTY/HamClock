#!/usr/bin/env bash
# =============================================================================
#  HamClock Improved — Build & Install Script for Fedora Linux
#  Builds an RPM from source and installs it with dnf.
#  Usage:  chmod +x build-and-install.sh && ./build-and-install.sh
# =============================================================================
set -euo pipefail

NAME="hamclock-improved"
VERSION="1.0.0"
APP_ID="org.w7cty.HamClockImproved"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_DIR="$SCRIPT_DIR/src/${NAME}-${VERSION}"
SPEC="$SCRIPT_DIR/SPECS/${NAME}.spec"

# ── Colours ───────────────────────────────────────────────────────────────────
RED='\033[0;31m'; GRN='\033[0;32m'; YLW='\033[1;33m'
CYN='\033[0;36m'; BLD='\033[1m'; NC='\033[0m'
info(){ echo -e "${CYN}[INFO]${NC}  $*"; }
ok()  { echo -e "${GRN}[ OK ]${NC}  $*"; }
warn(){ echo -e "${YLW}[WARN]${NC}  $*"; }
die() { echo -e "${RED}[ERR ]${NC}  $*" >&2; exit 1; }

# ── Banner ────────────────────────────────────────────────────────────────────
echo -e "${YLW}${BLD}"
cat << 'EOF'
  ██╗  ██╗ █████╗ ███╗   ███╗ ██████╗██╗      ██████╗  ██████╗██╗  ██╗
  ██║  ██║██╔══██╗████╗ ████║██╔════╝██║     ██╔═══██╗██╔════╝██║ ██╔╝
  ███████║███████║██╔████╔██║██║     ██║     ██║   ██║██║     █████╔╝
  ██╔══██║██╔══██║██║╚██╔╝██║██║     ██║     ██║   ██║██║     ██╔═██╗
  ██║  ██║██║  ██║██║ ╚═╝ ██║╚██████╗███████╗╚██████╔╝╚██████╗██║  ██╗
  ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝ ╚═════╝╚══════╝ ╚═════╝  ╚═════╝╚═╝  ╚═╝
  IMPROVED  ·  Fedora RPM Installer  ·  by W7CTY
EOF
echo -e "${NC}"

# ── Fedora check ──────────────────────────────────────────────────────────────
[[ -f /etc/fedora-release ]] || warn "Not Fedora — continuing anyway."
FEDORA_VER=$(rpm -q --queryformat '%{VERSION}' fedora-release 2>/dev/null || echo "?")
info "Fedora $FEDORA_VER detected"

# ── Step 1: Install build tools ────────────────────────────────────────────
info "Step 1/5 — Installing build tools..."
sudo dnf install -y \
    rpm-build \
    desktop-file-utils \
    libappstream-glib \
    rpmdevtools \
    2>/dev/null || die "dnf failed — check your internet connection."
ok "Build tools installed."

# ── Step 2: Set up rpmbuild tree ───────────────────────────────────────────
info "Step 2/5 — Setting up rpmbuild tree in ~/rpmbuild..."
rpmdev-setuptree
RPMTOP="$(rpm --eval '%{_topdir}')"
ok "RPM tree at $RPMTOP"

# ── Step 3: Create source tarball ─────────────────────────────────────────
info "Step 3/5 — Creating source tarball..."
TARBALL="$RPMTOP/SOURCES/${NAME}-${VERSION}.tar.gz"
tar -czf "$TARBALL" -C "$SCRIPT_DIR/src" "${NAME}-${VERSION}"
ok "Tarball: $TARBALL"

# Copy spec
cp "$SPEC" "$RPMTOP/SPECS/"
ok "Spec copied."

# ── Step 4: Build the RPM ─────────────────────────────────────────────────
info "Step 4/5 — Building RPM (rpmbuild)..."
rpmbuild -ba "$RPMTOP/SPECS/${NAME}.spec" \
    --define "_topdir $RPMTOP" \
    2>&1 | grep -v "^Processing\|^Executing\|^Provides\|^Requires\|^checking"

RPM_FILE=$(find "$RPMTOP/RPMS" -name "${NAME}-${VERSION}*.rpm" | head -1)
[[ -f "$RPM_FILE" ]] || die "RPM not found after build — check output above."
ok "RPM built: $RPM_FILE"

# Copy RPM to script dir for easy access
cp "$RPM_FILE" "$SCRIPT_DIR/"
BUNDLE="$SCRIPT_DIR/$(basename "$RPM_FILE")"
ok "RPM saved to: $BUNDLE"

# ── Step 5: Install ───────────────────────────────────────────────────────
info "Step 5/5 — Installing RPM with dnf..."

# Determine correct WebKitGTK package for this Fedora version
if [[ "$FEDORA_VER" -ge 40 ]] 2>/dev/null; then
    WEBKIT_PKG="webkitgtk6.0"
else
    WEBKIT_PKG="webkit2gtk4.1"
fi

# Install runtime dependencies first
sudo dnf install -y \
    python3 \
    python3-gobject \
    gtk4 \
    libadwaita \
    "$WEBKIT_PKG" \
    2>/dev/null || warn "Some deps may not have installed — continuing."

# Install the RPM
sudo dnf install -y "$BUNDLE" || sudo rpm -Uvh "$BUNDLE"

# ── Done ─────────────────────────────────────────────────────────────────────
echo ""
echo -e "${GRN}${BLD}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${GRN}${BLD}║       HamClock Improved installed successfully!       ║${NC}"
echo -e "${GRN}${BLD}╚═══════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  ${CYN}Launch from terminal:${NC}  hamclock-improved"
echo -e "  ${CYN}Launch from desktop:${NC}   Activities  →  HamClock Improved"
echo -e "  ${CYN}Uninstall:${NC}             sudo dnf remove hamclock-improved"
echo ""
echo -e "  ${YLW}73 de W7CTY  ·  w7cty@outlook.com${NC}"
echo ""
