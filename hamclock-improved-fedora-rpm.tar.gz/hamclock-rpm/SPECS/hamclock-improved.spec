Name:           hamclock-improved
Version:        1.0.0
Release:        1%{?dist}
Summary:        Amateur Radio Operations Center — HF Conditions, DX Spots, Propagation Map

License:        GPLv3+
URL:            mailto:w7cty@outlook.com
Source0:        %{name}-%{version}.tar.gz

BuildArch:      noarch

# ── Runtime dependencies ───────────────────────────────────────────────────
Requires:       python3 >= 3.8
Requires:       python3-gobject
Requires:       gtk4
Requires:       libadwaita

# WebKitGTK: prefer the GTK4-native 6.0 binding, fall back to 4.1
%if 0%{?fedora} >= 40
Requires:       webkitgtk6.0
%else
Requires:       webkit2gtk4.1
%endif

Requires:       hicolor-icon-theme

# ── Build dependencies (desktop-file-validate, appstream-util) ─────────────
BuildRequires:  desktop-file-utils
BuildRequires:  libappstream-glib

%description
HamClock Improved is a full-featured amateur radio operations center built
with GTK4 and WebKitGTK.  It displays real-time HF propagation conditions,
solar and geomagnetic indices, a live DX cluster spot feed, an interactive
National Geographic world map with day/night gray-line overlay, world clocks,
and a quick QSO logger supporting SSB, CW, FT8/FT4, DMR, D-STAR, C4FM and FM.

Features:
 • Solar Flux Index, Sunspot Number, K-index, A-index, X-ray class, Aurora
 • HF band conditions 160m–6m with separate day and night propagation quality
 • Interactive National Geographic world map (Esri NatGeo tiles)
 • Real-time gray-line terminator and great-circle DX paths
 • Maidenhead grid square with automatic GPS coordinate calculation
 • Live DX cluster spot feed with band and mode filtering
 • World clocks: UTC, ET, London, Moscow, Tokyo, Sydney
 • POTA, SOTA, Field Day and custom operation-type logging
 • Dark and light theme with persistent preferences
 • First-run setup wizard; shareable station links

%prep
%autosetup

%build
# Nothing to compile — pure Python + HTML

%install
# ── Application binary ─────────────────────────────────────────────────────
install -Dm755 hamclock \
    %{buildroot}%{_bindir}/hamclock-improved

# ── HTML data file ──────────────────────────────────────────────────────────
install -Dm644 hamclock.html \
    %{buildroot}%{_datadir}/hamclock-improved/hamclock.html

# ── Desktop entry ───────────────────────────────────────────────────────────
desktop-file-install \
    --dir=%{buildroot}%{_datadir}/applications \
    hamclock-improved.desktop

# ── App icon ────────────────────────────────────────────────────────────────
install -Dm644 org.w7cty.HamClockImproved.svg \
    %{buildroot}%{_datadir}/icons/hicolor/scalable/apps/org.w7cty.HamClockImproved.svg

# ── AppStream metainfo ───────────────────────────────────────────────────────
install -Dm644 org.w7cty.HamClockImproved.metainfo.xml \
    %{buildroot}%{_datadir}/metainfo/org.w7cty.HamClockImproved.metainfo.xml

%check
desktop-file-validate %{buildroot}%{_datadir}/applications/hamclock-improved.desktop

%post
/usr/bin/gtk-update-icon-cache -f -t %{_datadir}/icons/hicolor &>/dev/null || :
/usr/bin/update-desktop-database %{_datadir}/applications &>/dev/null || :

%postun
/usr/bin/gtk-update-icon-cache -f -t %{_datadir}/icons/hicolor &>/dev/null || :
/usr/bin/update-desktop-database %{_datadir}/applications &>/dev/null || :

%files
%license LICENSE
%{_bindir}/hamclock-improved
%{_datadir}/hamclock-improved/
%{_datadir}/applications/hamclock-improved.desktop
%{_datadir}/icons/hicolor/scalable/apps/org.w7cty.HamClockImproved.svg
%{_datadir}/metainfo/org.w7cty.HamClockImproved.metainfo.xml

%changelog
* Sun May 25 2026 W7CTY <w7cty@outlook.com> - 1.0.0-1
- Initial release of HamClock Improved
