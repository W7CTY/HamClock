# HamClock Improved — Fedora Linux RPM Package
### Amateur Radio Operations Center  ·  v1.0.0  ·  by W7CTY

---

## Instant Install (one command)

```bash
chmod +x build-and-install.sh
./build-and-install.sh
```

The script installs build tools, compiles the RPM, installs all dependencies,
and installs the app. Requires `sudo` and an internet connection.

---

## After Install

```bash
# Launch from terminal
hamclock-improved

# Or: press Super key → search "HamClock Improved"
```

---

## Uninstall

```bash
sudo dnf remove hamclock-improved
```

---

## What Gets Installed

| Path | Contents |
|---|---|
| `/usr/bin/hamclock-improved` | Executable (Python + GTK4 launcher) |
| `/usr/share/hamclock-improved/hamclock.html` | Full dashboard |
| `/usr/share/applications/hamclock-improved.desktop` | App launcher entry |
| `/usr/share/icons/hicolor/scalable/apps/` | App icon |
| `/usr/share/metainfo/` | AppStream metadata |

---

## Runtime Dependencies

Installed automatically by the build script:

| Package | Version |
|---|---|
| `python3` | 3.8+ |
| `python3-gobject` | any |
| `gtk4` | any |
| `libadwaita` | any |
| `webkitgtk6.0` | Fedora 40+ |
| `webkit2gtk4.1` | Fedora 38–39 |

---

## Keyboard Shortcuts

| Key | Action |
|---|---|
| `F5` | Reload |
| `F11` | Toggle fullscreen |
| `Esc` | Exit fullscreen |
| `Ctrl +` | Zoom in |
| `Ctrl −` | Zoom out |
| `Ctrl 0` | Reset zoom |
| `Ctrl Q` | Quit |

---

## Building the RPM Manually

If you prefer to build without auto-installing:

```bash
# 1. Install build tools
sudo dnf install -y rpm-build desktop-file-utils libappstream-glib rpmdevtools

# 2. Set up rpmbuild tree
rpmdev-setuptree

# 3. Create source tarball
tar -czf ~/rpmbuild/SOURCES/hamclock-improved-1.0.0.tar.gz \
    -C src hamclock-improved-1.0.0

# 4. Build
rpmbuild -ba SPECS/hamclock-improved.spec

# 5. Install
sudo dnf install ~/rpmbuild/RPMS/noarch/hamclock-improved-1.0.0-1.*.rpm
```

---

## Contact

**W7CTY** · [w7cty@outlook.com](mailto:w7cty@outlook.com)

*73 de W7CTY — Good DX!*
